require("amcharts3/amcharts/amcharts.js");
require("./animate.min.js");
